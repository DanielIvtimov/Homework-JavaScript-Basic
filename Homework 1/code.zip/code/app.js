console.log("==== First Exercise ===="); 
let p = 3.14; 
let r = 5.64;
let r2 = r * r;
let area = r2 * p; 
console.log("The area is: " + area); 

console.log("==== Second Exercise ====");
let onePhone = 119.95; 
let percent = 5 / 100; 
let tax = onePhone * percent;
let realPrice = onePhone + tax; 
let thirtyPhones = realPrice * 30;
console.log("The price of 30 phones is: " + thirtyPhones + "$");

